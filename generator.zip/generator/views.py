import os
from django.shortcuts import render, redirect
from django.conf import settings
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Search

from transformers import TFT5ForConditionalGeneration, RobertaTokenizer
import tensorflow as tf

def run_predict(model_path, tokenizer_path, text, max_input_length, max_target_length):
    # Load saved fine-tuned model
    model = TFT5ForConditionalGeneration.from_pretrained(model_path)

    # Load saved tokenizer
    tokenizer = RobertaTokenizer.from_pretrained(tokenizer_path)

    # Encode input text
    encoded_text = tokenizer(text, return_tensors='tf', padding='max_length', truncation=True, max_length=max_input_length)

    # Inference
    generated_code = model.generate(
        encoded_text["input_ids"], attention_mask=encoded_text["attention_mask"],
        max_length=max_target_length, top_p=0.95, top_k=50, repetition_penalty=2.0, num_return_sequences=1
    )

    # Decode generated tokens
    decoded_code = tokenizer.decode(generated_code.numpy()[0], skip_special_tokens=True)
    return decoded_code

@csrf_exempt
def generate_code(request):
    if request.method == 'POST':
        # Get the input text from the form
        input_text = request.POST.get('input_text', '')

        # Set the paths and parameters
        model_path = os.path.join(settings.BASE_DIR, 'saved_model')
        tokenizer_path = os.path.join(settings.BASE_DIR, 'saved_model')
        max_input_length = 300  # Set the appropriate value
        max_target_length = 300  # Set the appropriate value

        # Process the input text using the trained model
        generated_code = run_predict(model_path, tokenizer_path, input_text, max_input_length, max_target_length)

        # Save the search to the database
        search = Search.objects.create(text=input_text, generated_code=generated_code)

        # Redirect to the home page with the updated list of searches
        return redirect('home')
    else:
        return HttpResponse('Method Not Allowed')

def home(request):
    # Retrieve all saved searches from the database
    searches = Search.objects.all()

    return render(request, 'generator/index.html', {'searches': searches})
