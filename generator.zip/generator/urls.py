from django.urls import path
from .views import home, generate_code

urlpatterns = [
    path('', home, name='home'),
    path('generate_code/', generate_code, name='generate_code'),
]
